<?php
  
             
             
header("Content-Type: application/json; charset=utf-8");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Credentials: false');
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Origin");
header('P3P: CP="CAO PSA OUR"'); // Makes IE to support cookies

require('config.php');
include('password.php');

$user = new adduser();

$user->check();

class adduser{
    

public function check(){
     

    $send=['error'=>0,'msg'=>'','status'=>0];
     if(isset($_POST['userid']) && isset($_POST['password'])){
           if($_POST['userid']=='' || $_POST['password']==''){
         $send=['error'=>1,'msg'=>'Field should not be blank','status'=>0];
          echo json_encode($send);
        }else{ 
        
        $this->insertdata($_POST['userid'],$_POST['password']);
        }
  
   } else{
       
      
    $send=['error'=>1,'msg'=>'Post Parameter Not Mached eg:userid and password','status'=>0];
    echo json_encode($send);
     
         
  
    }
    
   

}



public function insertdata($userid,$password){
    
$date=date("jS F Y");
    $send=['error'=>0,'msg'=>'','status'=>0];
    try{
        $easydb = new easyfeature();


 $sqlusercheck="SELECT email FROM members WHERE email='$userid'";
  
  $resch=$easydb->checkduplicate($sqlusercheck);
  
  if($resch>0){
      
       $send=['error'=>1,'msg'=>'User Already Registered','status'=>0];
       echo json_encode($send);
  }else{
      
$sql="INSERT INTO `members` VALUES (NULL, 'sd', '$password', '$userid', '', NULL, 'No', '$date')";
$res=$easydb->insert($sql);
if($res=="Data Has succesfully Recorded"){
$send=['error'=>0,'msg'=>$res,'status'=>1];
    echo json_encode($send);
}else{
    $send=['error'=>1,'msg'=>'Try Again','status'=>0];
    echo json_encode($send);
    
}
  
}
      
    }
    
    catch(Exception $e) {
  echo 'Message: ' .$e->getMessage();
}
    
  
    
    
}





    
}


?>
