<?php
  
             
             
header("Content-Type: application/json; charset=utf-8");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Credentials: false');
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Origin");
header('P3P: CP="CAO PSA OUR"'); // Makes IE to support cookies

require('config.php');
include('password.php');

$user = new uploadimage();

$user->check();

class uploadimage{



public function check(){
     
   

    $send=['error'=>0,'msg'=>'','status'=>0];
     if(isset($_POST['clientid']) && isset($_POST['dealerid']) ){
            $easydb = new easyfeature();
    
              $im=$_POST['image']; 
$sql="INSERT INTO `addupload` VALUES (NULL, '$im' )";
$res=$easydb->insert($sql);
         
         
         
           if($_POST['clientid']=='' || $_POST['dealerid']=='') {
         $send=['error'=>1,'msg'=>'Field should not be blank','status'=>0];
          echo json_encode($send);
        }else{ 
            
      $file_name = $_FILES['image']['name'];
      $file_size =$_FILES['image']['size'];
      $file_tmp =$_FILES['image']['tmp_name'];
      $file_type=$_FILES['image']['type'];
      $file_ext=strtolower(end(explode('.',$file_name)));
            
      $extensions= array("jpeg","jpg","png");
      
      if(in_array($file_ext,$extensions)=== false){
          
          $send=['error'=>1,'msg'=>'Only jpg , png and jpeg format allowed','status'=>0];
          echo json_encode($send);
         exit;
      }
            
            
         $this->checkid($_POST['clientid'],$_POST['dealerid']);   
           
       // $this->insertdata($_POST['username'],$_POST['password'],$_POST['name']);
        }
  
   } else{
       
      
    $send=['error'=>1,'msg'=>'Post Parameter Not Mached eg:clientid , dealerid and image','status'=>0];
    echo json_encode($send);
     
         
  
    }
    
   

}


function checkid($cid,$did){
      $easydb = new easyfeature();
   
    
    
 $sqlclientcheck="SELECT id FROM addclients WHERE id='$cid'";
  $sqldealercheck="SELECT id FROM appuser WHERE id='$did'";
 
  $chclient=$easydb->checkduplicate($sqlclientcheck);
  $chdealer=$easydb->checkduplicate($sqldealercheck);
 
  if($chclient<1 || $chdealer<1 ){
       $send=['error'=>1,'msg'=>'Please Check your Clientid and Dealerid','status'=>0];
    echo json_encode($send);
      exit;
  }else{
      $this->checkfolder($cid,$did);
  }
    
    
    
    
    
    
    
}

public function checkfolder($cid,$did){
    
  $filedealer = "photoupload/".$did;
if(! is_dir($filedealer)) {
    

    mkdir($filedealer,0755,true); 
    
}
    
   $filedealerclient = "photoupload/".$did."/".$cid;   
  if(! is_dir($filedealerclient)) {

    mkdir($filedealerclient,0755,true); 
}  
  
  $this->insertdata($cid,$did);
    
}



function getRandom() { 
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'; 
    $randomString = ''; 
  
    for ($i = 0; $i < 10; $i++) { 
        $index = rand(0, strlen($characters) - 1); 
        $randomString .= $characters[$index]; 
    } 
  
    return $randomString; 
} 

public function insertdata($cid,$did){
$file_name = $_FILES['image']['name'];
 $file_tmp =$_FILES['image']['tmp_name'];
//$date=date("jS F Y");
$date=date("Y-m-d");
$ran=$this->getRandom();
    $send=['error'=>0,'msg'=>'','status'=>0];
    try{
        $easydb = new easyfeature();


 $sqlusercheck="SELECT username FROM appuser WHERE username='$username'";
  
  $resch=$easydb->checkduplicate($sqlusercheck);

$targetloc="photoupload/".$did."/".$cid."/";
$filenamestore=$ran.$file_name;


 if(move_uploaded_file($file_tmp,$targetloc.$filenamestore)){
     
     $send=['error'=>0,'msg'=>'Data Uploaded','status'=>1];
    echo json_encode($send);
     exit;
     
 }



 echo "Try Again";














exit;
      
$token=$this->getRandom();      
      
$sql="INSERT INTO `appuser` VALUES (NULL, '$name', '$username', '$password', '$token','$date')";
$res=$easydb->insert($sql);
if($res=="Data Has succesfully Recorded"){
$send=['error'=>0,'msg'=>$res,'status'=>1];
    echo json_encode($send);
}else{
    $send=['error'=>1,'msg'=>'Try Again','status'=>0];
    echo json_encode($send);
    
}
  

      
    }
    
    catch(Exception $e) {
  echo 'Message: ' .$e->getMessage();
}
    
  
    
    
}





    
}


?>
